package com.senai.task;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskSpringbootApplication.class, args);
	}

}
